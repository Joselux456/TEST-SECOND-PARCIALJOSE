
# I.
  Evidencia de paso de purebas del código.
  ![POOB-TEST-FIRST-SABANA-RESEARCH – ProjectTest java  POOB-TEST-FIRST-SABANA-RESEARCH test  4_16_2021 5_13_42 PM](https://user-images.githubusercontent.com/78450716/115094349-d21f5b80-9ee2-11eb-883e-b83ec826d323.png)
  Métodos: getDuration(): Este método obtiene la duración (en días) de un projecto, iteracion o actividad, y revisa si cada uno es válido, en caso contrario, lanza una excepción.
# II.
  Evidencia Diseño
  ![Diagrama clases medio editado](https://user-images.githubusercontent.com/78450716/115095123-aea9e000-9ee5-11eb-8dee-1896bf926f13.png)


## Conceptos:

  * Los 3 principales momentos de las excepciones son Lanzar, propagar y atrapar, el primero se caracteriza al ser cuando se detecta una excepción, entonces esta se lanza al ser detectada y para la ejecución, después en la propagación se envía información acerca de la excepción para que pueda ser encontrada y que se pueda solucionar, y finalmente al catch se imprime dicha información para que sea visible. En java se implementa el throw al ser detectada una excepción en un método, mediante un “if” o un mecanismo parecido, al propagar se habla acerca del error que transmite cada excepción y finalmente el catch en java se utiliza al mostrar el error en consola.

  * La sobreescritura de métodos es la práctica de tomar un método de una super clase o interfaz, e implementarlo con un cuerpo diferente, es bueno aplicarla ya que da una manera de utilizar un código preexistente y modificarlo con otros atributos. Una de las maneras que se puede impedir la sobreescritura es por el uso de la palabra clave “final” en el método que se piensa sobrescribir.
